import React from 'react'
import Person from './Person'
function NameList() {
    
    const persons =[
        {
            id: 1,
            name: 'Swarupa',
            age: 22,
            skill: 'React'
        },
        {
            id: 2,
            name: 'Deepika',
            age: 22,
            skill: 'Mulesoft'
        },
        {
            id: 3,
            name: 'Bhanu',
            age: 22,
            skill: 'Angular'
        }
    ]
    const personList = persons.map(person => <Person key={person.name} person={person} />) 
    return <div>{personList}</div>
    
}

export default NameList