import logo from './logo.svg';
import './App.css';
import Greet from './components/Greet'
import Welcome from './components/Welcome'
import Hello from './components/Hello'
import Message from './components/Message'
import Counter from './components/Counter'
import FunctionClick from './components/FunctionClick'
import ClassClick from './components/ClassClick'
import EventBind from './components/EventBind'
import ParentComponent from './components/ParentComponent'
import UserGreeting from './components/UserGreeting'
import NameList from './components/NameList'

function App() {
  return (
    <div className="App">
      <NameList />
      {/*<UserGreeting />*/}
      {/* <ParentComponent />}
      {/*<EventBind />
      <FunctionClick />
      <ClassClick />
      {/*<Counter/>
      {/*<Message />
      {/*<Greet name="Swarupa" heroName="Super Woman">
       <p>This is children props</p> 
      </Greet>
      <Greet name="Deepika" heroName="Wonder Woman">
        <button>Action</button>
      </Greet> 
      <Greet name="Bhavani" heroName="Pretty Woman"/>
      <Welcome name="Swarupa" heroName="Super Woman"/>
      <Welcome name="Deepika" heroName="Wonder Woman"/>
      <Welcome name="Bhavani" heroName="Pretty Woman"/>
      {/*<Hello/>*/}
    </div>
  );
}

export default App;
